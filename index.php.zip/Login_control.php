<?php
session_start();
check_email();
function connect_DB(){
    $servername = "localhost";
    $username = "nacmcaho_arab_board_exam";
    $password = "Gt(A2IndxS9X";
    $dbname = "nacmcaho_arab_board_exam";
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$servername;dbname=$dbname;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    try {
        $conn = new PDO($dsn, $username, $password, $options);
        return $conn;
    } catch(PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
        return false;
    }
}


function check_email(){
    if(isset($_POST['login__submit'])){
        $conn=connect_DB();
        if($conn != false){
            $sql = "SELECT count(*) FROM auth_email where email='".$_POST['login__input']."'";
            $result = $conn->query($sql);
           
            if ($result->fetchColumn() > 0){
                $_SESSION['email'] = $_POST['login__input'];
                header('Location: ./Registration.php');
            }
            else{
                echo "<script>document.getElementById('error_email').innerHTML ='أنت غير مسجل';</script>";
            }
        }
    }
}

function scientificcouncil() {
    $conn = connect_DB();
    if ($conn != false) {
        $sql = "SELECT * FROM scientificcouncil";
        $result = $conn->query($sql);

        if ($result->rowCount() > 0) {
            // Fetch data and return as an array
            $councils = array();
            while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                $councils[$row['ID']] = $row['Name_Arabic'];
            }
            return $councils;
        } else {
            // Handle no data available scenario
            echo "No data available";
            return array();
        }
    } else {
        // Handle database connection error
        echo "Connection error";
        return false;
    }
}

function retrieveExamCenters() {
    try {
        // اتصال بقاعدة البيانات
        $conn = connect_DB();
        
        // استعلام SQL لاسترجاع المراكز الامتحانية
        $sql = "SELECT * FROM exam_centers";
        $stmt = $conn->query($sql);

        // تحقق من وجود بيانات
        if ($stmt->rowCount() > 0) {
            // إعادة البيانات كمصفوفة
            $centers = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $centers;
        } else {
            // إذا لم يتم العثور على بيانات
            return array();
        }
    } catch(PDOException $e) {
        // معالجة الأخطاء في حالة حدوثها
        echo "Connection failed: " . $e->getMessage();
        return false;
    }
}

// الدالة لاستعادة بيانات البلدان
function retrieveCountries() {
    try {
        // اتصال بقاعدة البيانات
        $conn = connect_DB();
        
        // استعلام SQL لاسترجاع بيانات البلدان
        $sql = "SELECT * FROM countries";
        $stmt = $conn->query($sql);

        // تحقق من وجود بيانات
        if ($stmt->rowCount() > 0) {
            // إعادة البيانات كمصفوفة
            $countries = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $countries;
        } else {
            // إذا لم يتم العثور على بيانات
            return array();
        }
    } catch(PDOException $e) {
        // معالجة الأخطاء في حالة حدوثها
        echo "Connection failed: " . $e->getMessage();
        return false;
    }
}

?>