<?php
check_email();
function connect_DB(){
    $servername = "localhost";
    $username = "root";
    $password = "";

    try {
        $conn = new PDO("mysql:host=$servername;dbname=arab_board_exam", $username, $password);
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
      } catch(PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
        return false;
    }
}

function check_email(){
    if(isset($_POST['login__submit'])){
        $conn=connect_DB();
        if($conn != false){
            $sql = "SELECT count(*) FROM auth_email where email='".$_POST['login__input']."'";
            $result = $conn->query($sql);
           
            if ($result->fetchColumn() > 0){
                header('Location: ./Registration.php');
            }
            else{
                echo "<script>document.getElementById('error_email').innerHTML ='You are not registered';</script>";
            }
        }
    }
}
?>