<?php
Admin_login();
function connect_DB(){
    $servername = "localhost";
    $username = "root";
    $password = "";

    try {
        $conn = new PDO("mysql:host=$servername;dbname=arab_board_exam", $username, $password);
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
      } catch(PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
        return false;
    }
}

function Admin_login(){
    if(isset($_POST['login__submit'])){
        $conn=connect_DB();
        if($conn != false){
            $sql = "SELECT password FROM admins where email='".$_POST['login__email']."'";
            $result = $conn->query($sql);
            
            if ($result->rowCount() > 0){
                $end_res=$result->fetchAll();
                $verify = password_verify($_POST['login__password'], $end_res[0][0]); 
                if ($verify){
                    header('Location: ./viewdata_all.php');
                }
                else{
                    echo "<script>document.getElementById('error_password').innerHTML ='The password is incorrect';</script>";
                }
            }
            else{
                echo "<script>document.getElementById('error_email').innerHTML ='this Email is not registered';</script>";
            }
        }
    }
}
?>