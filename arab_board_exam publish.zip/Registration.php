<!DOCTYPE html>
<html lang="en" >
<head>
  	<meta charset="UTF-8">
  	<title>Registration</title>
  	<link rel="icon" href="logo.svg" type="image/icon type">
  	<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.2.0/css/all.css'>
	<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.2.0/css/fontawesome.css'>
	<link rel="stylesheet" href="./Login.css">
</head>
<body>
    Registration 
	<a href='./Login.php'>login</a>
</body>
</html>
